name = "j a c k     s    he    phard"
for ch in name:
    if not ch.isspace():
        print(ch)
