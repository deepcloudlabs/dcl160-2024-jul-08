"""
string -> str -> class
collection -> character
[] -> ordered
immutable
methods: i. transformation (upper, lower, capitalize, title, ...)
        ii. filtering (strip, lstrip, rstrip, replace, ...)
       iii. query (is______)
binary stream vs character stream -> file operations
"""