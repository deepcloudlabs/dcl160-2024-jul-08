name = "jack shephard"
print(name.title())
# TypeError: 'str' object does not support item assignment
# error: name[0] = 'J'
