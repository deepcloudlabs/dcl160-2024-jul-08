name = "     \n   \n  \t\t\n    jack shephard\n\n\n\t\t\t\t     \t  "
print(name)
print(len(name))
print(name.lstrip())
print(name.rstrip())
print(name.strip())
