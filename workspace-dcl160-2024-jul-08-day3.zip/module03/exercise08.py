line = "to be or not to be"
print(line)
print(line.replace("to", "2"))
