name = "jack shephard"
print(name)
name = name.title()
# name -> "Jack Shephard"
# "jack shephard" -> garbage -> garbage collector
print(name)
