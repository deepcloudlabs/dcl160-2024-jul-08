numbers = [4, 8, 15, 16, 23, 42]
print(numbers)
del numbers[1::2]
# numbers[1::2] = []
print(numbers)
