numbers = [4, 8, 15, 16, 23, 42]
print(numbers[0])
print(numbers[1])
# IndexError: list index out of range
#error: print(numbers[6])
print(numbers[-1])
print(numbers[-2])
print(numbers[-6])
#error: print(numbers[-7])
print(numbers[0:3])
print(numbers[:3])
print(numbers[0:4:2])
print(numbers[1:6:2])
