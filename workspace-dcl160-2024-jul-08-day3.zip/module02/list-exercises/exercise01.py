# list: ordered, mutable, duplicates
numbers = [4, 8, 15, 16, 23, 42]
print(len(numbers))
grades = [
    ("490606", "A+"),
    ("491615", "F")
]
print(grades)
grades.append(("490682", "C+"))
print(grades)
