# set: un-ordered, mutable, unique
numbers = {4, 8, 15, 16, 23, 42}
print(len(numbers))
print(numbers)
numbers.add(47)
print(numbers)
# list: ordered, mutable, duplicates
list = [4, 8, 15, 16, 23, 42]
list.append(9)
print(len(list))
print(list)
