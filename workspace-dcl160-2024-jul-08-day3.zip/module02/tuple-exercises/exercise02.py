# tuple ()
jack = ("jack", "bauer", 100_000, "tr1", ["IT", "Sales"])
print(len(jack))
print(jack[0])  # first name
print(jack[1])  # last name
print(jack[2])  # salary
print(jack[4][0])  # first department
print(type(jack[0]))  # str
print(type(jack[1]))  # str
print(type(jack[2]))  # int
print(type(jack[4]))  # list
print(type(jack[4][0]))  # str
