jack = ("jack", "bauer", 100_000, "tr1", ["IT", "Sales"])
print(jack[1])
print(jack[1][3])
# error: jack[1][3] = "E"
