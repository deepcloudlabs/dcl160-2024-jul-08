jack = ("jack", "bauer", 100_000, "tr1", ["IT", "Sales"])
first_name = jack[0]
last_name = jack[1]
salary = jack[2]
iban = jack[3]