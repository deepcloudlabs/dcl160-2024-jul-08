jack = ("jack", "bauer", 100_000, "tr1", ["IT", "Sales"])
print(jack[0])
print(jack[1])
# error: print(jack[5])

print(jack[-1])
print(jack[-2])
# error: print(jack[-6])
