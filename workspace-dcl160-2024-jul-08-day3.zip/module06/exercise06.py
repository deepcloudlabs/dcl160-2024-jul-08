for i in range(1,1_000_000):
    print(i)