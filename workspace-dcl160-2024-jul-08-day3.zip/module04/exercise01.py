"""
i. if
   if/else
   if/elif/else
   if/elif/elif/else
   condition -> if, elif -> True/False

ii. loops:
    a. regular loops: for -> iterables: tuple/list/set/dictionary/str/...
    b. irregular loops: while -> condition -> True/False
"""