numbers = [4, 8, 15, 16, 23, 42]
evens = []
for number in numbers:
    if number % 2 == 0:
        evens.append(number)
print(evens)
