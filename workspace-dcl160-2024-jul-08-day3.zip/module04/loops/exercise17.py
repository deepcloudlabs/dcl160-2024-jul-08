week_day = "friday"
match week_day:
    case "monday" | "tuesday" | "wednesday" | "thursday" | "friday":
        print("work hard!")
    case "saturday" | "sunday":
        print("rest")

