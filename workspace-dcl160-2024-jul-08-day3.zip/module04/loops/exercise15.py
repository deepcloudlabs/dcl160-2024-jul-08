week_day = "friday"
day = 0
if week_day == "monday":
    day = 1
elif week_day == "tuesday":
    day = 2
elif week_day == "wednesday":
    day = 3
elif week_day == "thursday":
    day = 4
elif week_day == "friday":
    day = 5
elif week_day == "saturday":
    day = 6
else:
    day = 0
print(day)
