numbers = [4, 8, None, 15, None, None, 16, None, 23, None, 42, None]
# regular loop
for number in numbers:
    if number is not None:
        print(number)
