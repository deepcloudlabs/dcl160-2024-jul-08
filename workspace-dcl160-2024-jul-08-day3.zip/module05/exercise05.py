def fun(x, y=2, z):  # error -> since z has no default value
    return x * y + z

