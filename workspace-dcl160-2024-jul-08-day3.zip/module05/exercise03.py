def fun(x, y, z):
    return x * y + z


result1 = fun(1, 2, 3)
result2 = fun(z=3, x=1, y=2)
