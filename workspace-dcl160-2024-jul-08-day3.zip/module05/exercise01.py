"""
Procedural Programming -> function
 A. General Function
 B. Special Functions:
 i. generator function
ii. async function
"""