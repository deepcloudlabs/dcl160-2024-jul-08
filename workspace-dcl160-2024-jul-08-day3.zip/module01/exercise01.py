x = 42
y = 108
print(x, y)
x = x ^ y
y = x ^ y
x = x ^ y
print(x, y)
