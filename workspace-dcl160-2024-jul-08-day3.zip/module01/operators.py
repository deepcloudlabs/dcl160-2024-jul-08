x = 42  # 0010 1010
y = 108 # 0110 1100
print(x + y)
print(x - y)
print(x * y)
print(x // y)
print(x / y)
print(x ^ y)  # bitwise xor 0100 0110 -> 70
print(x & y)  # bitwise and 0010 1000 -> 40
print(x | y)  # bitwise or  0110 1110 -> 110
