"""
1. Exception -> Failures
Type I Error -> Fix -> Maintenance -> Exception
Type II Error -> File/DB/Kafka/UI  -> Exception

2. File: I/O Operations
File -> Persistence
data -> memory: list/set/tuples/dict -> persist -> file
        file: i. text i/o
             ii. binary i/o
"""